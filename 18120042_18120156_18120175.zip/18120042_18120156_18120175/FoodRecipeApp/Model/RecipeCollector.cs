﻿using FoodRecipe.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodRecipeApp.Model
{
    public class RecipeCollector : BaseViewModel
    {
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        private string _DisplayName;

        public string DisplayName
        {
            get { return _DisplayName; }
            set { _DisplayName = value; }
        }

        private string _Image;

        public string Image
        {
            get { return _Image; }
            set { _Image = value; }
        }

        private bool _Loved;

        public bool Loved
        {
            get { return _Loved; }
            set { _Loved = value; }
        }

        private string _Color;

        public string Color
        {
            get { return _Color; }
            set { _Color = value; OnPropertyChanged(); }
        }


        public RecipeCollector(int id, string displayName, string image, bool loved)
        {
            Id = id;
            DisplayName = displayName;
            Image = "Images/" + image;
            Loved = loved;
            GetColor();
        }

        public void GetColor()
        {
            if(Loved == true)
            {
                Color = "pink";
            }
            else
            {
                Color = "white";
            }
        }
    }
}
