﻿using FoodRecipe.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FoodRecipeApp.ViewModel
{
    public class MainViewModel : BaseViewModel
    {
        public ICommand HomeCommand { get; set; }
        public ICommand LoveCommand { get; set; }
        public ICommand SearchCommand { get; set; }
        public ICommand AddRecipeCommand { get; set; }
        public ICommand SettingCommand { get; set; }

        public MainViewModel()
        {
            HomeCommand = new RelayCommand<object>((p) => { return true; }, (p) =>
             {
                 HomeScreen hs = new HomeScreen();
                 hs.ShowDialog();
             });

            LoveCommand = new RelayCommand<object>((p) => { return true; }, (p) =>
            {
                LoveScreen ls = new LoveScreen();
                ls.ShowDialog();
            });

            SearchCommand = new RelayCommand<object>((p) => { return true; }, (p) =>
            {
                SearchScreen ss = new SearchScreen();
                ss.ShowDialog();
            });

            AddRecipeCommand = new RelayCommand<object>((p) => { return true; }, (p) =>//chưa có sceen
            {
                LoveScreen ls = new LoveScreen();
                ls.ShowDialog();
            });

            SettingCommand = new RelayCommand<object>((p) => { return true; }, (p) =>//chưa có screen
            {
                LoveScreen ls = new LoveScreen();
                ls.ShowDialog();
            });
        }
    }
}
