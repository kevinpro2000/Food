﻿using FoodRecipe.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FoodRecipeApp.ViewModel
{
    public class MainViewModel : BaseViewModel
    {
        public ICommand HomeCommand { get; set; }
        public ICommand LoveCommand { get; set; }

        public MainViewModel()
        {
            HomeCommand = new RelayCommand<object>((p) => { return true; }, (p) =>
             {
                 HomeScreen hs = new HomeScreen();
                 hs.ShowDialog();
             });

            LoveCommand = new RelayCommand<object>((p) => { return true; }, (p) =>
            {
                LoveScreen ls = new LoveScreen();
                ls.ShowDialog();
            });
        }
    }
}
