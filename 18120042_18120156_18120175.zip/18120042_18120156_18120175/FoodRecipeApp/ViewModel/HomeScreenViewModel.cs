﻿using FoodRecipe.ViewModel;
using FoodRecipeApp.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FoodRecipeApp.ViewModel
{
    public class HomeScreenViewModel : BaseViewModel
    {
        private ObservableCollection<RecipeCollector> _Foods;
        public ObservableCollection<RecipeCollector> Foods { get => _Foods; set { _Foods = value; OnPropertyChanged();} }

        private RecipeCollector _SelectedItem;

        public RecipeCollector SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; }
        }


        public ICommand DetailCommand { get; set; }
        public ICommand LoveCommand { get; set; }
        public ICommand DeleteLoveCommand { get; set; }
        public ICommand RefreshCommand { get; set; }

        public HomeScreenViewModel()
        {
            RenewList();
            LoveCommand = new RelayCommand<object>((p) =>
            {
                if (SelectedItem == null)
                {
                    return false;
                }
                if (SelectedItem.Loved == true)
                {
                    return false;                }
                return true;
            }, (p) =>
            {
                var recipe = DataProvider.Ins.DB.Recipes.Where(x => x.id == SelectedItem.Id).SingleOrDefault();
                recipe.loved = 1;
                DataProvider.Ins.DB.SaveChanges();
                var recipeList = Foods.Where(x => x.Id == SelectedItem.Id).SingleOrDefault();
                recipeList.Loved = true;
                recipeList.GetColor();
                OnPropertyChanged("Foods");
            });

            DeleteLoveCommand = new RelayCommand<object>((p) =>
            {
                if (SelectedItem == null)
                {
                    return false;
                }
                if (SelectedItem.Loved == false)
                {
                    return false;
                }
                return true;
            }, (p) =>
            {
                var recipe = DataProvider.Ins.DB.Recipes.Where(x => x.id == SelectedItem.Id).SingleOrDefault();
                recipe.loved = 0;
                DataProvider.Ins.DB.SaveChanges();
                var recipeList = Foods.Where(x => x.Id == SelectedItem.Id).SingleOrDefault();
                recipeList.Loved = false;
                recipeList.GetColor();
                OnPropertyChanged("Foods");
            });

            DetailCommand = new RelayCommand<object>((p) =>
            {
                if (SelectedItem == null)
                {
                    return false;
                }
                return true;
            }, (p) =>
            {
                DetailScreen dc = new DetailScreen();
                dc.ShowDialog();
            });

            RefreshCommand = new RelayCommand<object>((p) =>
            {
                return true;
            }, (p) =>
            {
                RenewList();
            });
        }

        private void RenewList()
        {
            Foods = new ObservableCollection<RecipeCollector>();
            var Items = new ObservableCollection<Recipe>(DataProvider.Ins.DB.Recipes);
            foreach (var item in Items)
            {
                bool isloved = false;
                if (item.loved == 1)
                {
                    isloved = true;
                }
                var food = new RecipeCollector(item.id, item.displayName, item.imageLink, isloved);
                Foods.Add(food);
            }
            OnPropertyChanged("Foods");
        }
    }
}
