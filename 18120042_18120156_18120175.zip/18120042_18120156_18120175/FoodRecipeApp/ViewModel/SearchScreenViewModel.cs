﻿using FoodRecipe.ViewModel;
using FoodRecipeApp.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FoodRecipeApp.ViewModel
{
    public class SearchScreenViewModel : BaseViewModel
    {
        private ObservableCollection<RecipeCollector> _Foods;
        public ObservableCollection<RecipeCollector> Foods { get => _Foods; set { _Foods = value; OnPropertyChanged(); } }

        private RecipeCollector _SelectedItem;

        public RecipeCollector SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; }
        }

        private string _SearchText;

        public string SearchText
        {
            get { return _SearchText; }
            set { _SearchText = value; }
        }



        public ICommand DetailCommand { get; set; }
        public ICommand LoveCommand { get; set; }
        public ICommand DeleteLoveCommand { get; set; }
        public ICommand SearchCommand { get; set; }

        public SearchScreenViewModel()
        {
            SearchText = "";
            Foods = new ObservableCollection<RecipeCollector>();
            var Items = new List<Recipe>(DataProvider.Ins.DB.Recipes);
            foreach (var item in Items)
            {
                bool isloved = false;
                if (item.loved == 1)
                {
                    isloved = true;
                }
                var food = new RecipeCollector(item.id, item.displayName, item.imageLink, isloved);
                Foods.Add(food);
            }

            LoveCommand = new RelayCommand<object>((p) =>
            {
                if (SelectedItem == null)
                {
                    return false;
                }
                if (SelectedItem.Loved == true)
                {
                    return false;
                }
                return true;
            }, (p) =>
            {
                var recipe = DataProvider.Ins.DB.Recipes.Where(x => x.id == SelectedItem.Id).SingleOrDefault();
                recipe.loved = 1;
                DataProvider.Ins.DB.SaveChanges();
                var recipeList = Foods.Where(x => x.Id == SelectedItem.Id).SingleOrDefault();
                recipeList.Loved = true;
                recipeList.GetColor();
                OnPropertyChanged("Foods");
            });

            DeleteLoveCommand = new RelayCommand<object>((p) =>
            {
                if (SelectedItem == null)
                {
                    return false;
                }
                if (SelectedItem.Loved == false)
                {
                    return false;
                }
                return true;
            }, (p) =>
            {
                var recipe = DataProvider.Ins.DB.Recipes.Where(x => x.id == SelectedItem.Id).SingleOrDefault();
                recipe.loved = 0;
                DataProvider.Ins.DB.SaveChanges();
                var recipeList = Foods.Where(x => x.Id == SelectedItem.Id).SingleOrDefault();
                recipeList.Loved = false;
                recipeList.GetColor();
                OnPropertyChanged("Foods");
            });

            SearchCommand = new RelayCommand<object>((p) =>
            {
                if (string.IsNullOrEmpty(SearchText))
                {
                    return false;
                }
                else
                {
                    return true;
                }

            }, (p) =>
            {
                Foods.Clear();
                var recipes = DataProvider.Ins.DB.Recipes.Where(x=> x.displayName.Contains(SearchText));
                foreach(var item in recipes)
                {
                    bool isloved = false;
                    if (item.loved == 1)
                    {
                        isloved = true;
                    }
                    var food = new RecipeCollector(item.id, item.displayName, item.imageLink, isloved);
                    Foods.Add(food);
                }
                OnPropertyChanged("Foods");
            });
        }

    }
}
