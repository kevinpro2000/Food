﻿using FoodRecipe.ViewModel;
using FoodRecipeApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FoodRecipeApp.ViewModel
{
    public class SearchScreenViewModel : BaseViewModel
    {
        private List<RecipeCollector> _Foods;
        public List<RecipeCollector> Foods { get => _Foods; set { _Foods = value; OnPropertyChanged(); } }

        private RecipeCollector _SelectedItem;

        public RecipeCollector SelectedItem
        {
            get { return _SelectedItem; }//Dừng ở đoạn này
            set { _SelectedItem = value; }
        }


        public ICommand DetailCommand { get; set; }
        public ICommand LoveCommand { get; set; }


        public SearchScreenViewModel()
        {
            Foods = new List<RecipeCollector>();
            var Items = new List<Recipe>(DataProvider.Ins.DB.Recipes);
            foreach (var item in Items)
            {
                bool isloved = false;
                if (item.loved == 1)
                {
                    isloved = true;
                }
                var food = new RecipeCollector(item.id, item.displayName, item.imageLink, isloved);
                Foods.Add(food);
            }
        }
    }
}
